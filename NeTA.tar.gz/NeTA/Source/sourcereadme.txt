1. Download the Project file.
2. Open it in android studio.
3. Run it on android simulator. 
4. or install it in an android device and run it.