git link: 
https://git.cse.iitb.ac.in/vineethsai/CS699Project_NeTA


roll numbers of the teammates with Project name:
Project Name: NeTA (Android App)
Vineeth Sai - 193050031
Jayabrata Das - 193050085
Billoh Gassama - 193051001


contribution of each individual:
Everyone contributed equally on the project. 


motivation:

Today most students finds it very difficult to have a common platform to share information about booking a cab irrespective of the distance. The initiative behind this project is as a result of the increasing price of fuel, which also causes the cost of rides to increase drastically. It is against these backdrops that we deemed it necessary to help solve these problems by developing the NeTA app. NeTA will help you in such situations as mentioned above,if one has to book a ride alone for him or herself, then their will be an  increase in cost. This cost can easily be reduced by sharing the ride with others. But most of the time, it is very difficult to find such companions. And because of this most people have to hire a ride alone. This app solves such problems by connecting people who are going to the same place or nearby location. Thus it does not only helps people to save money but also reduces the use of fuel by reducing the number of rides.




basics of how to host from the developer documentation:

It is a simple android project. To run the program one have to download the project and run in on android studio or install the apk in android device and run it.
